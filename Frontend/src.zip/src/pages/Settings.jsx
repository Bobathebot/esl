// src/pages/Settings.jsx
import React from 'react';
import { Typography } from '@mui/material';

const Settings = () => {
  return (
    <div>
      <Typography variant="h4">Settings</Typography>
    </div>
  );
};

export default Settings;
