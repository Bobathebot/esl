// src/pages/Questions.jsx
import React from 'react';
import { Typography } from '@mui/material';

const Questions = () => {
  return (
    <div>
      <Typography variant="h4">Manage Questions</Typography>
      {/* Add form or table for questions */}
    </div>
  );
};

export default Questions;
