// src/pages/Students.jsx
import React from 'react';
import { Typography } from '@mui/material';

const Students = () => {
  return (
    <div>
      <Typography variant="h4">Student List</Typography>
      {/* Add table or list of students */}
    </div>
  );
};

export default Students;
