// src/components/Settings.js
import React from 'react';
import { Typography } from '@mui/material';

const Settings = () => {
  return (
    <div>
      <Typography variant="h4">Settings</Typography>
      {/* Add settings form or options here */}
    </div>
  );
};

export default Settings;
