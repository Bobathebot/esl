// src/components/Questions.js
import React from 'react';
import { Typography } from '@mui/material';

const Questions = () => {
  return (
    <div>
      <Typography variant="h4">Manage Questions</Typography>
      {/* Add questions management content here */}
    </div>
  );
};

export default Questions;
