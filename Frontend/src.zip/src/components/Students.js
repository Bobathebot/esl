// src/components/Students.js
import React from 'react';
import { Typography } from '@mui/material';

const Students = () => {
  return (
    <div>
      <Typography variant="h4">Student List</Typography>
      {/* Add students table or cards here */}
    </div>
  );
};

export default Students;
